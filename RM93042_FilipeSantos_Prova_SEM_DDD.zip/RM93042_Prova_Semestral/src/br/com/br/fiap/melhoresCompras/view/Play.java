package br.com.br.fiap.melhoresCompras.view;

import java.util.Scanner;

import br.com.fiap.melhoresCompras.model.Eletronico;
import br.com.fiap.melhoresCompras.model.Eletroportateis;
import br.com.fiap.melhoresCompras.model.Moveis;
import br.com.fiap.melhoresCompras.model.Pedido;
import br.com.fiap.melhoresCompras.model.Perfumes;

public class Play {

	public static void main(String[] args) {

	Eletronico eletronico = new Eletronico("IPAD", "Apple", 10, 3500.00, "Tablet");
	Eletroportateis eletroportatil = new Eletroportateis("Cafeteira Nesspresso", "Arno", 50,350.00,"Cozinha" ,"110V");
	Moveis movel = new Moveis("Cama Queen Size","Castor",5,2220.20,"Madeira/algodao",30);
	Perfumes perfume = new Perfumes("Sauvage","DIOR",15,349.50,50,"amadeirado");
	
	Scanner entrada = new Scanner(System.in);
	entrada.useDelimiter("[\r\n]+");
	
	System.out.println("---------------Bem vindo as Melhores Compras--------------------------------------------------------");
	System.out.println("Digite seu nome para Come�ar:");
	String cliente= entrada.next();
	System.out.println("=========================ESTAS S�O AS OFERTAS QUE SEPARAMOS PARA VOCE ======================================================");
	System.out.println("1- "+eletronico.getNome()+" "+eletronico.getMarca()+" "+eletronico.getTipo()+": R$ "+eletronico.getValor()+"\n"+
					   "2- "+eletroportatil.getNome()+" "+eletroportatil.getMarca()+" "+eletroportatil.getCategoriaUso()+          ": R$ "+eletroportatil.getValor()+"\n"+
					   "3- "+movel.getNome()+" "+movel.getMarca()+" "+movel.getMaterial()+": R$ "+movel.getValor()+"\n"+
					   "4- "+perfume.getNome()+" "+perfume.getMarca()+" "+perfume.getLitragem()+" ml "+perfume.getAroma()+" :R$ "+perfume.getValor()+"\n");
	System.out.println("-----------------------------------------------------------------------------------------------------");
	
	System.out.println("Digite a op��o para realizar seu pedido "+ cliente.toUpperCase()+": ");
	int flag = entrada.nextInt();
	
	
	switch (flag) {
	case 1: {
		
		System.out.println("Digite a Quantidade do produto que quer adquirir");
		int quantidade =entrada.nextInt();
				
		
		System.out.println("Digite a Forma de Pagamento");
		String formapgto=entrada.next();
		
		Pedido pedido = new Pedido(cliente,eletronico,formapgto,quantidade);
		
		System.out.println("Esse � o seu pedido");
		System.out.println(pedido);
		
		double totalPagar=pedido.fechaPedido(); 
		
		System.out.println("O valor total � de R$:"+totalPagar );
		
		System.out.println("Pedido realizado com sucesso");
		System.out.println("--------------------------------------------------------------------------------------------------------");
		
		System.out.println("Informa��es sobre o estoque atual: "+eletronico.getNome()+" "+eletronico.getEstoque()+" no Estoque");
		
	
		break;
	}
	case 2: {
		
		System.out.println("Digite a Quantidade do produto que quer adquirir");
		int quantidade =entrada.nextInt();
				
		
		System.out.println("Digite a Forma de Pagamento");
		String formapgto=entrada.next();
		
		Pedido pedido = new Pedido(cliente,eletroportatil,formapgto,quantidade);
		
		System.out.println("Esse � o seu pedido");
		System.out.println(pedido);
		
		double totalPagar=pedido.fechaPedido(); 
		
		System.out.println("O valor total � de R$:"+totalPagar );
		
		System.out.println("Pedido realizado com sucesso");
		System.out.println("--------------------------------------------------------------------------------------------------------");
		
		System.out.println("Informa��es sobre o estoque atual: "+eletroportatil.getNome()+" "+eletroportatil.getEstoque()+" no Estoque");
	break;
	
	
	
	}
	
	case 3: {
		
		System.out.println("Digite a Quantidade do produto que quer adquirir");
		int quantidade =entrada.nextInt();
				
		
		System.out.println("Digite a Forma de Pagamento");
		String formapgto=entrada.next();
		
		Pedido pedido = new Pedido(cliente,movel,formapgto,quantidade);
		
		System.out.println("Esse � o seu pedido");
		System.out.println(pedido);
		
		double totalPagar=pedido.fechaPedido(0.89,movel.getPeso()); 
		
		System.out.println("O valor total � de R$:"+totalPagar+ " via : "+pedido.getFormapgto());
		
		System.out.println("Pedido realizado com sucesso");
		System.out.println("--------------------------------------------------------------------------------------------------------");
		
		System.out.println("Informa��es sobre o estoque atual: "+movel.getNome()+" "+movel.getEstoque()+" no Estoque");
	   
		break;
	
	
	
	}
	
case 4: {
		
		System.out.println("Digite a Quantidade do produto que quer adquirir");
		int quantidade =entrada.nextInt();
				
		
		System.out.println("Digite a Forma de Pagamento");
		String formapgto=entrada.next();
		
		Pedido pedido = new Pedido(cliente,perfume,formapgto,quantidade);
		
		System.out.println("Esse � o seu pedido");
		System.out.println(pedido);
		
		double totalPagar=pedido.fechaPedido(); 
		
		System.out.println("O valor total � de R$:"+totalPagar );
		
		System.out.println("Pedido realizado com sucesso");
		System.out.println("--------------------------------------------------------------------------------------------------------");
		
		System.out.println("Informa��es sobre o estoque atual: "+perfume.getNome()+" "+perfume.getEstoque()+" no Estoque");
	   
		break;
	
	
	
	}
			
	default:
		System.err.println("Oferta n�o Encontrada");
	}
	
	
	
	entrada.close();	
	
	}

	 
	

	
	

}
